//app/composables/useAuth.js
// CRITICAL: Proper memory management using ref instead of reactive for simple values
// and useState for global state to prevent memory leaks

export const useAuth = () => {
  // Use useState for global auth state - auto cleans up on navigation
  const user = useState('auth-user', () => null)
  const token = useState('auth-token', () => null)
  const isAuthenticated = useState('auth-authenticated', () => false)
  
  // Use ref for local reactive state
  const loading = ref(false)
  const error = ref(null)

  const config = useRuntimeConfig()
  const router = useRouter()

  const login = async (credentials) => {
    loading.value = true
    error.value = null

    try {
      const response = await $fetch(`${config.public.apiBase}/auth/local`, {
        method: 'POST',
        body: credentials
      })

      // Update global state
      user.value = response.user
      token.value = response.jwt
      isAuthenticated.value = true

      // Store in localStorage for persistence
      if (process.client) {
        localStorage.setItem('auth-token', response.jwt)
        localStorage.setItem('auth-user', JSON.stringify(response.user))
      }

      await router.push('/dashboard')
      return response
    } catch (err) {
      error.value = err.message || 'Login failed'
      throw err
    } finally {
      loading.value = false
    }
  }

  const logout = async () => {
    // Clear state
    user.value = null
    token.value = null
    isAuthenticated.value = false

    // Clear localStorage
    if (process.client) {
      localStorage.removeItem('auth-token')
      localStorage.removeItem('auth-user')
    }

    await router.push('/login')
  }

  const initAuth = () => {
    if (process.client) {
      const storedToken = localStorage.getItem('auth-token')
      const storedUser = localStorage.getItem('auth-user')

      if (storedToken && storedUser) {
        token.value = storedToken
        user.value = JSON.parse(storedUser)
        isAuthenticated.value = true
      }
    }
  }

  // CRITICAL: Use computed for derived values to maintain reactivity without memory leaks
  const userRole = computed(() => user.value?.role?.type || null)
  const userName = computed(() => user.value?.username || '')

  return {
    user: readonly(user),
    token: readonly(token),
    isAuthenticated: readonly(isAuthenticated),
    userRole,
    userName,
    loading: readonly(loading),
    error: readonly(error),
    login,
    logout,
    initAuth
  }
}