//app/composables/useAdverts.js
export const useAdverts = () => {
  // Use useState for list data that persists across navigation
  const adverts = useState('adverts-list', () => [])
  const currentAdvert = useState('current-advert', () => null)
  
  // Use ref for UI state that's component-specific
  const loading = ref(false)
  const error = ref(null)
  const pagination = ref({
    page: 1,
    pageSize: 25,
    total: 0
  })

  const config = useRuntimeConfig()
  const { token } = useAuth()

  // Fetch adverts with filters
  const fetchAdverts = async (filters = {}) => {
    loading.value = true
    error.value = null

    try {
      const queryParams = new URLSearchParams({
        'pagination[page]': pagination.value.page,
        'pagination[pageSize]': pagination.value.pageSize,
        ...filters
      })

      const response = await $fetch(`${config.public.apiBase}/adverts?${queryParams}`, {
        headers: {
          Authorization: `Bearer ${token.value}`
        }
      })

      // CRITICAL: Replace entire array to maintain reactivity
      adverts.value = response.data
      pagination.value.total = response.meta.pagination.total

      return response.data
    } catch (err) {
      error.value = err.message
      throw err
    } finally {
      loading.value = false
    }
  }

  // Get single advert
  const fetchAdvert = async (id) => {
    loading.value = true
    error.value = null

    try {
      const response = await $fetch(`${config.public.apiBase}/adverts/${id}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token.value}`
        },
        params: {
          populate: ['client', 'product', 'attachments', 'comments', 'workflow_history']
        }
      })

      currentAdvert.value = response.data
      return response.data
    } catch (err) {
      error.value = err.message
      throw err
    } finally {
      loading.value = false
    }
  }

  // Create advert
  const createAdvert = async (advertData, files = []) => {
    loading.value = true
    error.value = null

    try {
      // Upload files first if present
      let uploadedFileIds = []
      if (files.length > 0) {
        const formData = new FormData()
        files.forEach(file => {
          formData.append('files', file)
        })

        const uploadResponse = await $fetch(`${config.public.apiBase}/upload`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token.value}`
          },
          body: formData
        })

        uploadedFileIds = uploadResponse.map(file => file.id)
      }

      // Create advert with file references
      const response = await $fetch(`${config.public.apiBase}/adverts`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token.value}`,
          'Content-Type': 'application/json'
        },
        body: {
          data: {
            ...advertData,
            attachments: uploadedFileIds
          }
        }
      })

      // Add to list
      adverts.value = [response.data, ...adverts.value]
      
      return response.data
    } catch (err) {
      error.value = err.message
      throw err
    } finally {
      loading.value = false
    }
  }

  // Update advert
  const updateAdvert = async (id, advertData) => {
    loading.value = true
    error.value = null

    try {
      const response = await $fetch(`${config.public.apiBase}/adverts/${id}`, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${token.value}`,
          'Content-Type': 'application/json'
        },
        body: {
          data: advertData
        }
      })

      // Update in list
      const index = adverts.value.findIndex(a => a.id === id)
      if (index !== -1) {
        adverts.value[index] = response.data
      }

      if (currentAdvert.value?.id === id) {
        currentAdvert.value = response.data
      }

      return response.data
    } catch (err) {
      error.value = err.message
      throw err
    } finally {
      loading.value = false
    }
  }

  // CRITICAL: Computed values for filtered/derived data
  const draftAdverts = computed(() => 
    adverts.value.filter(a => a.attributes?.status === 'draft')
  )

  const pendingAdverts = computed(() => 
    adverts.value.filter(a => a.attributes?.status === 'pending_review')
  )

  // Clean up function - call in onBeforeUnmount
  const cleanup = () => {
    // Reset only component-specific state
    loading.value = false
    error.value = null
    // Keep adverts and currentAdvert in useState for cross-component sharing
  }

  return {
    adverts: readonly(adverts),
    currentAdvert: readonly(currentAdvert),
    loading: readonly(loading),
    error: readonly(error),
    pagination: readonly(pagination),
    draftAdverts,
    pendingAdverts,
    fetchAdverts,
    fetchAdvert,
    createAdvert,
    updateAdvert,
    cleanup
  }
}