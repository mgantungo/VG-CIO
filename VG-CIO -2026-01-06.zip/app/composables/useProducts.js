//app/composables/useProducts.js
export const useProducts = () => {
  // Use useState for cached product data
  const products = useState('products-list', () => [])
  const categories = useState('product-categories', () => [])
  const rateCards = useState('rate-cards', () => {})
  
  const loading = ref(false)
  const error = ref(null)

  const config = useRuntimeConfig()
  const { token } = useAuth()

  const fetchProducts = async () => {
    if (products.value.length > 0) {
      // Return cached data
      return products.value
    }

    loading.value = true
    error.value = null

    try {
      const response = await $fetch(`${config.public.apiBase}/products`, {
        headers: {
          Authorization: `Bearer ${token.value}`
        },
        params: {
          populate: ['category'],
          'pagination[pageSize]': 100
        }
      })

      products.value = response.data
      return response.data
    } catch (err) {
      error.value = err.message
      throw err
    } finally {
      loading.value = false
    }
  }

  const fetchCategories = async () => {
    if (categories.value.length > 0) {
      return categories.value
    }

    loading.value = true
    error.value = null

    try {
      const response = await $fetch(`${config.public.apiBase}/product-categories`, {
        headers: {
          Authorization: `Bearer ${token.value}`
        }
      })

      categories.value = response.data
      return response.data
    } catch (err) {
      error.value = err.message
      throw err
    } finally {
      loading.value = false
    }
  }

  const fetchRateCards = async (productId) => {
    // Check cache
    if (rateCards.value[productId]) {
      return rateCards.value[productId]
    }

    loading.value = true
    error.value = null

    try {
      const response = await $fetch(
        `${config.public.apiBase}/products/${productId}/rate-cards`,
        {
          headers: {
            Authorization: `Bearer ${token.value}`
          }
        }
      )

      // CRITICAL: Use Object.assign to maintain reactivity
      rateCards.value = {
        ...rateCards.value,
        [productId]: response.data
      }

      return response.data
    } catch (err) {
      error.value = err.message
      throw err
    } finally {
      loading.value = false
    }
  }

  const calculatePrice = async (priceData) => {
    loading.value = true
    error.value = null

    try {
      const response = await $fetch(`${config.public.apiBase}/adverts/calculate-price`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token.value}`,
          'Content-Type': 'application/json'
        },
        body: priceData
      })

      return response
    } catch (err) {
      error.value = err.message
      throw err
    } finally {
      loading.value = false
    }
  }

  // Computed helpers
  const productsByCategory = computed(() => {
    const grouped = {}
    products.value.forEach(product => {
      const categoryId = product.attributes.category?.data?.id
      if (categoryId) {
        if (!grouped[categoryId]) {
          grouped[categoryId] = []
        }
        grouped[categoryId].push(product)
      }
    })
    return grouped
  })

  return {
    products: readonly(products),
    categories: readonly(categories),
    rateCards: readonly(rateCards),
    loading: readonly(loading),
    error: readonly(error),
    productsByCategory,
    fetchProducts,
    fetchCategories,
    fetchRateCards,
    calculatePrice
  }
}