<!--app/layouts/default.vue-->
<template>
  <div class="app-layout">
    <AppHeader />
    <div class="layout-body">
      <SideMenu />
      <main class="main-content">
        <slot />
      </main>
    </div>
  </div>
</template>

<script setup>
const { initAuth } = useAuth()

// Initialize auth on app mount
onMounted(() => {
  initAuth()
})
</script>

<style scoped>
.app-layout {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.layout-body {
  display: flex;
  flex: 1;
  margin-top: 70px;
}

.main-content {
  flex: 1;
  margin-left: 250px;
  padding: 30px;
  background: var(--vg-gray);
  min-height: calc(100vh - 70px);
}

@media (max-width: 768px) {
  .main-content {
    margin-left: 0;
  }
}
</style>