<!--app/pages/index.vue-->
<template>
  <div class="landing-page">
    <section class="hero-section">
      <div class="container">
        <div class="hero-logo">VG</div>
        <h1>Vision Group Advertising Management System</h1>
        <p>
          Streamline your advertising operations across Print, TV, Radio, Digital, 
          and more. From booking to billing, manage everything in one powerful platform.
        </p>
        <!-- Option 1: Simple anchor tag with router navigation -->
        <a 
          href="/login" 
          class="btn btn-primary cta-button"
        >
          Get Started →
        </a>
        <!-- Option 2: If you want client-side navigation (remove the above and use this) -->
        <!--
        <button 
          @click="goToLogin" 
          class="btn btn-primary cta-button"
        >
          Get Started →
        </button>
        -->
      </div>
    </section>

    <section class="features-section">
      <div class="container">
        <h2>What You Can Do</h2>
        <p class="subtitle">
          A comprehensive solution for managing advertising across all Vision Group platforms
        </p>

        <div class="features-grid">
          <div 
            v-for="feature in features" 
            :key="feature.id"
            class="feature-card"
          >
            <div class="feature-icon">{{ feature.icon }}</div>
            <h3>{{ feature.title }}</h3>
            <p>{{ feature.description }}</p>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { useRouter } from '#imports'

const router = useRouter()

// CRITICAL: Use ref for reactive data that's local to this component
const features = ref([
  {
    id: 1,
    icon: '📝',
    title: 'Advert Booking',
    description: 'Create and book adverts across multiple platforms with real-time pricing.'
  },
  {
    id: 2,
    icon: '✓',
    title: 'Editorial Review',
    description: 'Sub-editors review submitted adverts for compliance and quality.'
  },
  {
    id: 3,
    icon: '👨‍💼',
    title: 'Manager Approval',
    description: 'Review revenue projections vs costs with financial oversight.'
  },
  {
    id: 4,
    icon: '🎨',
    title: 'Design House',
    description: 'Access approved adverts and manage creative materials.'
  },
  {
    id: 5,
    icon: '💰',
    title: 'Finance & Billing',
    description: 'Track payments, generate invoices, and manage revenue.'
  },
  {
    id: 6,
    icon: '📊',
    title: 'Analytics Dashboard',
    description: 'Real-time revenue tracking and performance metrics.'
  }
])

// If you want client-side navigation (use with button option)
const goToLogin = () => {
  router.push('/login')
}

definePageMeta({
  layout: 'auth'
})
</script>

<style scoped>
.landing-page {
  min-height: 100vh;
}

.hero-section {
  background: linear-gradient(135deg, var(--vg-dark-blue) 0%, var(--vg-light-blue) 100%);
  color: white;
  padding: 100px 20px;
  text-align: center;
}

.hero-logo {
  width: 150px;
  height: 150px;
  margin: 0 auto 30px;
  background: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2em;
  font-weight: bold;
  color: var(--vg-red);
}

.hero-section h1 {
  font-size: 3em;
  margin-bottom: 20px;
  font-weight: 700;
}

.hero-section p {
  font-size: 1.3em;
  margin-bottom: 30px;
  max-width: 800px;
  margin-left: auto;
  margin-right: auto;
}

.cta-button {
  display: inline-block;
  padding: 15px 40px;
  font-size: 1.1em;
  text-decoration: none;
  border: none;
  cursor: pointer;
}

.btn-primary {
  background: var(--vg-red);
  color: white;
  border-radius: 5px;
  transition: background-color 0.3s;
}

.btn-primary:hover {
  background: #c01820;
}

.features-section {
  padding: 80px 20px;
  background-color: var(--vg-gray);
}

.features-section h2 {
  text-align: center;
  color: var(--vg-dark-blue);
  font-size: 2.5em;
  margin-bottom: 20px;
}

.subtitle {
  text-align: center;
  color: #666;
  max-width: 800px;
  margin: 0 auto 50px;
  font-size: 1.1em;
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 30px;
  margin-top: 50px;
}

.feature-card {
  background: white;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
  border-left: 4px solid var(--vg-red);
  transition: transform 0.3s;
}

.feature-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 6px 12px rgba(0,0,0,0.15);
}

.feature-icon {
  width: 60px;
  height: 60px;
  background: var(--vg-light-blue);
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5em;
  margin-bottom: 20px;
}

.feature-card h3 {
  color: var(--vg-dark-blue);
  margin-bottom: 15px;
  font-size: 1.3em;
}

.feature-card p {
  color: #666;
  line-height: 1.8;
}

/* Responsive styles */
@media (max-width: 768px) {
  .hero-section {
    padding: 60px 20px;
  }
  
  .hero-section h1 {
    font-size: 2.2em;
  }
  
  .hero-section p {
    font-size: 1.1em;
  }
  
  .features-section {
    padding: 60px 20px;
  }
  
  .features-section h2 {
    font-size: 2em;
  }
  
  .features-grid {
    grid-template-columns: 1fr;
    gap: 20px;
  }
}

@media (max-width: 480px) {
  .hero-logo {
    width: 120px;
    height: 120px;
    font-size: 1.5em;
  }
  
  .hero-section h1 {
    font-size: 1.8em;
  }
  
  .hero-section p {
    font-size: 1em;
  }
  
  .cta-button {
    padding: 12px 30px;
    font-size: 1em;
  }
}
</style>