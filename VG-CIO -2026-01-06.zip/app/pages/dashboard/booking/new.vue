<!--app/pages/dashboard/new.vue-->
<template>
  <div class="booking-page">
    <div class="page-header">
      <h1>Book New Advert</h1>
      <p>Create a new advertising booking across Vision Group platforms</p>
    </div>

    <div class="card">
      <div class="card-header">
        <h2>Client & Advert Information</h2>
      </div>

      <form @submit.prevent="handleSubmit">
        <!-- Client Information -->
        <div class="form-row">
          <div class="form-group">
            <label>Client Name *</label>
            <input
              v-model="formData.clientName"
              type="text"
              placeholder="e.g., MTN Uganda"
              required
            />
          </div>
          <div class="form-group">
            <label>Contact Person</label>
            <input
              v-model="formData.contactPerson"
              type="text"
              placeholder="Contact name"
            />
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>Email Address *</label>
            <input
              v-model="formData.email"
              type="email"
              placeholder="client@company.com"
              required
            />
          </div>
          <div class="form-group">
            <label>Phone Number *</label>
            <input
              v-model="formData.phone"
              type="tel"
              placeholder="+256 700 000 000"
              required
            />
          </div>
        </div>

        <!-- Advert Details -->
        <div class="form-group">
          <label>Advert Title *</label>
          <input
            v-model="formData.advertTitle"
            type="text"
            placeholder="e.g., MTN New Year Campaign"
            required
          />
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>Platform Category *</label>
            <select
              v-model="formData.categoryId"
              @change="handleCategoryChange"
              required
            >
              <option value="">Select category</option>
              <option
                v-for="category in categories"
                :key="category.id"
                :value="category.id"
              >
                {{ category.attributes.category_name }}
              </option>
            </select>
          </div>
          <div class="form-group">
            <label>Specific Platform *</label>
            <select
              v-model="formData.productId"
              @change="handleProductChange"
              :disabled="!formData.categoryId"
              required
            >
              <option value="">Select platform</option>
              <option
                v-for="product in filteredProducts"
                :key="product.id"
                :value="product.id"
              >
                {{ product.attributes.product_name }}
              </option>
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>Ad Size/Duration *</label>
            <select
              v-model="formData.rateCardId"
              @change="calculateAdvertPrice"
              :disabled="!formData.productId"
              required
            >
              <option value="">Select size</option>
              <option
                v-for="rateCard in currentRateCards"
                :key="rateCard.id"
                :value="rateCard.id"
              >
                {{ rateCard.attributes.ad_type }} - 
                {{ rateCard.attributes.size_dimension || rateCard.attributes.duration }}
              </option>
            </select>
          </div>
          <div class="form-group">
            <label>Color/Type</label>
            <select v-model="formData.adType" @change="calculateAdvertPrice">
              <option value="full_color">Full Color</option>
              <option value="black_white">Black & White</option>
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>Frequency</label>
            <input
              v-model.number="formData.frequency"
              type="number"
              min="1"
              @change="calculateAdvertPrice"
            />
          </div>
          <div class="form-group">
            <label>Payment Method *</label>
            <select v-model="formData.paymentMethod" required>
              <option value="">Select payment method</option>
              <option value="cash">Cash</option>
              <option value="credit">Credit (Requires Approval)</option>
              <option value="pdc">Post-Dated Cheque</option>
              <option value="bank_transfer">Bank Transfer</option>
              <option value="mobile_money">Mobile Money</option>
            </select>
          </div>
        </div>

        <!-- Price Calculator Display -->
        <div v-if="priceCalculation" class="pricing-calculator">
          <h3>Price Calculation</h3>
          <div class="price-row">
            <span>Base Price:</span>
            <span>UGX {{ formatCurrency(priceCalculation.basePrice) }}</span>
          </div>
          <div class="price-row">
            <span>Frequency (× {{ formData.frequency }}):</span>
            <span>UGX {{ formatCurrency(priceCalculation.subtotal) }}</span>
          </div>
          <div class="price-row">
            <span>Surcharge ({{ priceCalculation.surchargePercentage }}%):</span>
            <span>UGX {{ formatCurrency(priceCalculation.surcharge) }}</span>
          </div>
          <div class="price-row total">
            <span>Total Amount:</span>
            <span>UGX {{ formatCurrency(priceCalculation.total) }}</span>
          </div>
        </div>

        <!-- File Upload -->
        <FileUpload @files-selected="handleFilesSelected" />

        <!-- Action Buttons -->
        <div class="action-buttons">
          <button type="button" class="btn btn-secondary" @click="saveDraft">
            Save as Draft
          </button>
          <button type="submit" class="btn btn-primary" :disabled="loading">
            {{ loading ? 'Submitting...' : 'Submit for Review' }}
          </button>
        </div>

        <div v-if="error" class="error-message">
          {{ error }}
        </div>
      </form>
    </div>
  </div>
</template>

<script setup>
// CRITICAL: Import composables
const { fetchCategories, fetchProducts, fetchRateCards, calculatePrice, 
        products, categories } = useProducts()
const { createAdvert, loading, error } = useAdverts()
const router = useRouter()

// CRITICAL: Use ref for all form data - avoids memory leaks
const formData = ref({
  clientName: '',
  contactPerson: '',
  email: '',
  phone: '',
  advertTitle: '',
  categoryId: '',
  productId: '',
  rateCardId: '',
  adType: 'full_color',
  frequency: 1,
  paymentMethod: '',
  specialInstructions: ''
})

const selectedFiles = ref([])
const priceCalculation = ref(null)
const currentRateCards = ref([])

// CRITICAL: Computed for filtered data - maintains reactivity
const filteredProducts = computed(() => {
  if (!formData.value.categoryId) return []
  return products.value.filter(p => 
    p.attributes.category?.data?.id === formData.value.categoryId
  )
})

// Load initial data
onMounted(async () => {
  await fetchCategories()
  await fetchProducts()
})

const handleCategoryChange = () => {
  // Reset dependent fields
  formData.value.productId = ''
  formData.value.rateCardId = ''
  currentRateCards.value = []
  priceCalculation.value = null
}

const handleProductChange = async () => {
  formData.value.rateCardId = ''
  priceCalculation.value = null
  
  if (formData.value.productId) {
    const rateCards = await fetchRateCards(formData.value.productId)
    currentRateCards.value = rateCards
  }
}

const calculateAdvertPrice = async () => {
  if (!formData.value.rateCardId) return

  const priceData = {
    productId: formData.value.productId,
    rateCardId: formData.value.rateCardId,
    frequency: formData.value.frequency,
    adType: formData.value.adType
  }

  priceCalculation.value = await calculatePrice(priceData)
}

const handleFilesSelected = (files) => {
  selectedFiles.value = files
}

const handleSubmit = async () => {
  const advertData = {
    advert_title: formData.value.advertTitle,
    product: formData.value.productId,
    rate_card: formData.value.rateCardId,
    ad_type: formData.value.adType,
    frequency: formData.value.frequency,
    payment_method: formData.value.paymentMethod,
    base_price: priceCalculation.value.basePrice,
    surcharge: priceCalculation.value.surcharge,
    total_amount: priceCalculation.value.total,
    status: 'pending_review'
  }

  await createAdvert(advertData, selectedFiles.value)
  router.push('/dashboard/booking')
}

const saveDraft = async () => {
  // Save as draft logic
  formData.value.status = 'draft'
  await handleSubmit()
}

// CRITICAL: Cleanup on unmount
onBeforeUnmount(() => {
  formData.value = {
    clientName: '',
    contactPerson: '',
    email: '',
    phone: '',
    advertTitle: '',
    categoryId: '',
    productId: '',
    rateCardId: '',
    adType: 'full_color',
    frequency: 1,
    paymentMethod: '',
    specialInstructions: ''
  }
  selectedFiles.value = []
  priceCalculation.value = null
  currentRateCards.value = []
})

// Helper function
const formatCurrency = (amount) => {
  return new Intl.NumberFormat('en-UG').format(amount || 0)
}
</script>

<style scoped>
.page-header {
  background: white;
  padding: 20px 30px;
  border-radius: 10px;
  margin-bottom: 30px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.page-header h1 {
  color: var(--vg-dark-blue);
  margin-bottom: 10px;
}

.card {
  background: white;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.card-header {
  margin-bottom: 25px;
  padding-bottom: 15px;
  border-bottom: 2px solid var(--vg-gray);
}

.card-header h2 {
  color: var(--vg-dark-blue);
}

.form-row {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: var(--vg-dark-gray);
  font-weight: 500;
}

.form-group input,
.form-group select {
  width: 100%;
  padding: 12px 15px;
  border: 1px solid var(--vg-border);
  border-radius: 5px;
  font-size: 1em;
}

.pricing-calculator {
  background: var(--vg-gray);
  padding: 20px;
  border-radius: 10px;
  margin: 20px 0;
}

.pricing-calculator h3 {
  color: var(--vg-dark-blue);
  margin-bottom: 15px;
}

.price-row {
  display: flex;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid var(--vg-border);
}

.price-row.total {
  border-top: 2px solid var(--vg-dark-blue);
  border-bottom: none;
  font-size: 1.3em;
  font-weight: bold;
  color: var(--vg-dark-blue);
  padding-top: 15px;
  margin-top: 10px;
}

.action-buttons {
  display: flex;
  gap: 15px;
  justify-content: flex-end;
  margin-top: 30px;
}

.error-message {
  background: #fee;
  color: var(--danger);
  padding: 10px;
  border-radius: 5px;
  margin-top: 20px;
}
</style>