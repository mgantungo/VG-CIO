<!--app/pages/login.vue-->
<template>
  <div class="login-page">
    <div class="login-container">
      <div class="login-header">
        <div class="login-logo">VG</div>
        <h2>Welcome Back</h2>
        <p>Sign in to access your dashboard</p>
      </div>

      <form @submit.prevent="handleLogin">
        <div class="form-group">
          <label for="email">Email Address</label>
          <input
            id="email"
            v-model="formData.identifier"
            type="email"
            placeholder="your.email@visiongroup.co.ug"
            required
          />
        </div>

        <div class="form-group">
          <label for="password">Password</label>
          <input
            id="password"
            v-model="formData.password"
            type="password"
            placeholder="••••••••"
            required
          />
        </div>

        <div v-if="error" class="error-message">
          {{ error }}
        </div>

        <button type="submit" class="btn btn-primary login-button" :disabled="loading">
          {{ loading ? 'Signing in...' : 'Sign In' }}
        </button>
      </form>
    </div>
  </div>
</template>

<script setup>
// CRITICAL: Use ref for component-local form state
const formData = ref({
  identifier: '',
  password: ''
})

const { login, loading, error } = useAuth()

const handleLogin = async () => {
  try {
    await login(formData.value)
    // Navigation handled in useAuth composable
  } catch (err) {
    // Error handled in useAuth composable
    console.error('Login failed:', err)
  }
}

// CRITICAL: Clean up on unmount to prevent memory leaks
onBeforeUnmount(() => {
  formData.value = { identifier: '', password: '' }
})

definePageMeta({
  layout: 'auth',
  middleware: 'guest' // Redirect if already authenticated
})
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  background: linear-gradient(135deg, var(--vg-dark-blue) 0%, var(--vg-light-blue) 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.login-container {
  background: white;
  padding: 50px;
  border-radius: 10px;
  box-shadow: 0 10px 25px rgba(0,0,0,0.2);
  max-width: 450px;
  width: 100%;
}

.login-header {
  text-align: center;
  margin-bottom: 40px;
}

.login-logo {
  width: 100px;
  height: 100px;
  background: var(--vg-red);
  color: white;
  border-radius: 50%;
  margin: 0 auto 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2em;
  font-weight: bold;
}

.login-header h2 {
  color: var(--vg-dark-blue);
  margin-bottom: 10px;
}

.login-header p {
  color: #666;
}

.form-group {
  margin-bottom: 25px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: var(--vg-dark-gray);
  font-weight: 500;
}

.form-group input {
  width: 100%;
  padding: 12px 15px;
  border: 1px solid var(--vg-border);
  border-radius: 5px;
  font-size: 1em;
  transition: border-color 0.3s;
}

.form-group input:focus {
  outline: none;
  border-color: var(--vg-light-blue);
}

.error-message {
  background: #fee;
  color: var(--danger);
  padding: 10px;
  border-radius: 5px;
  margin-bottom: 20px;
}

.login-button {
  width: 100%;
  padding: 12px;
  font-size: 1.1em;
}

.login-button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
</style>