<template>
  <header class="app-header">
    <div class="header-left">
      <NuxtLink to="/" class="logo">
        <h1>Vision Group Adverts</h1>
      </NuxtLink>
    </div>
    
    <div class="header-center">
      <nav class="main-nav">
        <NuxtLink to="/" class="nav-link">Dashboard</NuxtLink>
        <NuxtLink to="/adverts" class="nav-link" v-if="isAuthenticated">My Adverts</NuxtLink>
        <NuxtLink to="/booking/new" class="nav-link" v-if="canCreateAdvert">Book Advert</NuxtLink>
        <NuxtLink to="/review" class="nav-link" v-if="canReview">Review Adverts</NuxtLink>
      </nav>
    </div>
    
    <div class="header-right">
      <div v-if="isAuthenticated" class="user-menu">
        <div class="user-info">
          <span class="user-name">{{ displayName }}</span>
          <span class="user-role">{{ formattedRole }}</span>
        </div>
        <button class="logout-btn" @click="handleLogout">Logout</button>
      </div>
      <div v-else class="auth-buttons">
        <NuxtLink to="/auth/login" class="btn btn-primary">Login</NuxtLink>
      </div>
    </div>
  </header>
</template>

<script setup>
import { useAuth } from '~/composables/useAuth'
import { computed } from 'vue'

const auth = useAuth()
const user = auth?.user || ref(null)
const userRole = auth?.userRole || ref(null)
const logout = auth?.logout || (() => {
  console.warn('Logout function not available')
})

// Check if user is authenticated
const isAuthenticated = computed(() => {
  return !!user?.value
})

// Safely get display name
const displayName = computed(() => {
  if (!user?.value) return 'Guest'
  return user.value.name || user.value.email || 'User'
})

// Safely get formatted role
const formattedRole = computed(() => {
  if (!userRole?.value) return ''
  const role = userRole.value
  return role.charAt(0).toUpperCase() + role.slice(1)
})

// Check permissions
const canCreateAdvert = computed(() => {
  if (!userRole?.value) return false
  const role = userRole.value
  return ['clerk', 'admin', 'supervisor'].includes(role)
})

const canReview = computed(() => {
  if (!userRole?.value) return false
  const role = userRole.value
  return ['reviewer', 'admin', 'supervisor'].includes(role)
})

// Safe logout handler
const handleLogout = () => {
  if (typeof logout === 'function') {
    logout()
  } else {
    console.error('Logout function not available')
    // Redirect to login page as fallback
    window.location.href = '/auth/login'
  }
}
</script>

<style scoped>
.app-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
  height: 70px;
  background: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  position: sticky;
  top: 0;
  z-index: 1000;
}

.header-left .logo {
  text-decoration: none;
  color: #003366;
}

.header-left h1 {
  font-size: 1.5rem;
  margin: 0;
  font-weight: 600;
}

.header-center {
  flex: 1;
  display: flex;
  justify-content: center;
}

.main-nav {
  display: flex;
  gap: 30px;
}

.nav-link {
  text-decoration: none;
  color: #555;
  font-weight: 500;
  padding: 5px 10px;
  border-radius: 5px;
  transition: all 0.3s;
}

.nav-link:hover {
  color: #003366;
  background: #f5f5f5;
}

.nav-link.router-link-active {
  color: #E31E24;
  font-weight: 600;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 20px;
}

.user-menu {
  display: flex;
  align-items: center;
  gap: 15px;
}

.user-info {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}

.user-name {
  font-weight: 600;
  color: #333;
}

.user-role {
  font-size: 0.85rem;
  color: #666;
  background: #f0f0f0;
  padding: 2px 8px;
  border-radius: 12px;
}

.logout-btn {
  padding: 8px 16px;
  background: #dc3545;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 0.9rem;
  transition: background 0.3s;
}

.logout-btn:hover {
  background: #c82333;
}

.auth-buttons .btn {
  padding: 8px 20px;
  text-decoration: none;
  border-radius: 5px;
}

.btn-primary {
  background: #E31E24;
  color: white;
  border: none;
}

.btn-primary:hover {
  background: #c01820;
}

@media (max-width: 768px) {
  .app-header {
    flex-direction: column;
    height: auto;
    padding: 15px;
    gap: 15px;
  }
  
  .header-center {
    order: 3;
    width: 100%;
  }
  
  .main-nav {
    justify-content: center;
    flex-wrap: wrap;
    gap: 15px;
  }
  
  .user-info {
    align-items: center;
  }
}
</style>