import { ref } from 'vue'

export const useProducts = () => {
  const platforms = ref([])
  const products = ref([])
  const rateCards = ref([])
  const loading = ref(false)
  
  const loadPlatforms = async (category) => {
    loading.value = true
    try {
      // Mock data based on category
      const platformData = {
        print: ['New Vision', 'Bukedde', 'Weekend Vision', 'Bukedde Ku Wiikendi'],
        tv: ['UBC TV', 'Bukedde TV'],
        radio: ['Central Broadcasting', 'Radio stations'],
        digital: ['Website - New Vision', 'Website - Bukedde', 'Mobile App', 'Social Media'],
        outdoor: ['Billboards', 'Transit Advertising', 'Experiential Marketing']
      }
      
      platforms.value = platformData[category] || []
    } catch (error) {
      console.error('Failed to load platforms:', error)
      throw error
    } finally {
      loading.value = false
    }
  }
  
  const loadProducts = async (platform) => {
    loading.value = true
    try {
      // Mock data based on platform
      if (platform.includes('New Vision')) {
        products.value = [
          { id: '1', name: 'Front Page', category: 'display' },
          { id: '2', name: 'Back Page', category: 'display' },
          { id: '3', name: 'Main Body Display', category: 'display' },
          { id: '4', name: 'Classified', category: 'classified' }
        ]
      } else if (platform.includes('UBC TV')) {
        products.value = [
          { id: '5', name: 'Prime Time (30 sec)', category: 'spot' },
          { id: '6', name: 'Day Time (15 sec)', category: 'spot' },
          { id: '7', name: 'News Bulletin', category: 'sponsorship' }
        ]
      } else {
        products.value = [
          { id: '8', name: 'Standard Package', category: 'package' }
        ]
      }
    } catch (error) {
      console.error('Failed to load products:', error)
      throw error
    } finally {
      loading.value = false
    }
  }
  
  const loadRateCards = async (productId) => {
    loading.value = true
    try {
      // Mock rate cards
      rateCards.value = [
        {
          id: '1',
          name: 'Full Page - Standard Rate',
          productId,
          basePrice: 9470000,
          surchargePercentage: 10,
          effectiveDate: '2024-01-01',
          expiryDate: '2024-12-31',
          currency: 'UGX'
        },
        {
          id: '2',
          name: 'Half Page - Corporate Rate',
          productId,
          basePrice: 4850000,
          surchargePercentage: 5,
          effectiveDate: '2024-01-01',
          expiryDate: '2024-12-31',
          currency: 'UGX'
        }
      ]
    } catch (error) {
      console.error('Failed to load rate cards:', error)
      throw error
    } finally {
      loading.value = false
    }
  }
  
  return {
    platforms,
    products,
    rateCards,
    loading,
    loadPlatforms,
    loadProducts,
    loadRateCards
  }
}