import { ref } from 'vue'

export const usePayments = () => {
  const invoices = ref([])
  const loading = ref(false)
  const collectedThisMonth = ref(32000000)
  const outstanding = ref(18000000)
  const pendingPayments = ref(28)
  const collectionRate = ref(64)
  
  const loadInvoices = async () => {
    loading.value = true
    try {
      // Mock data
      invoices.value = [
        {
          id: '1',
          invoiceNumber: '#INV-2025-001',
          clientName: 'MTN Uganda',
          advertReference: '#ADV-2025-001',
          totalAmount: 15500000,
          amountPaid: 0,
          balance: 15500000,
          paymentMethod: 'credit',
          paymentStatus: 'unpaid',
          invoiceDate: '2025-01-05',
          dueDate: '2025-02-05'
        },
        {
          id: '2',
          invoiceNumber: '#INV-2025-002',
          clientName: 'Coca-Cola',
          advertReference: '#ADV-2025-002',
          totalAmount: 2500000,
          amountPaid: 2500000,
          balance: 0,
          paymentMethod: 'bank_transfer',
          paymentStatus: 'paid',
          invoiceDate: '2025-01-04',
          dueDate: '2025-01-19'
        },
        {
          id: '3',
          invoiceNumber: '#INV-2025-003',
          clientName: 'Airtel Uganda',
          advertReference: '#ADV-2025-004',
          totalAmount: 8200000,
          amountPaid: 5000000,
          balance: 3200000,
          paymentMethod: 'cash',
          paymentStatus: 'partial',
          invoiceDate: '2025-01-05',
          dueDate: '2025-02-05'
        },
        {
          id: '4',
          invoiceNumber: '#INV-2025-004',
          clientName: 'Stanbic Bank',
          advertReference: '#ADV-2025-003',
          totalAmount: 1800000,
          amountPaid: 0,
          balance: 1800000,
          paymentMethod: 'credit',
          paymentStatus: 'overdue',
          invoiceDate: '2024-12-15',
          dueDate: '2025-01-15'
        }
      ]
    } catch (error) {
      console.error('Failed to load invoices:', error)
      throw error
    } finally {
      loading.value = false
    }
  }
  
  const loadPaymentStats = async () => {
    loading.value = true
    try {
      // Mock API call for stats
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve()
        }, 500)
      })
    } catch (error) {
      console.error('Failed to load payment stats:', error)
      throw error
    } finally {
      loading.value = false
    }
  }
  
  const recordPayment = async (invoiceId, paymentData) => {
    loading.value = true
    try {
      // Mock API call
      return new Promise((resolve) => {
        setTimeout(() => {
          console.log(`Recording payment for invoice ${invoiceId}:`, paymentData)
          resolve()
        }, 1000)
      })
    } catch (error) {
      console.error('Failed to record payment:', error)
      throw error
    } finally {
      loading.value = false
    }
  }
  
  const getPaymentHistory = async (invoiceId) => {
    loading.value = true
    try {
      // Mock data
      return new Promise((resolve) => {
        setTimeout(() => {
          const history = [
            {
              id: '1',
              invoiceId,
              amount: 2500000,
              paymentMethod: 'bank_transfer',
              referenceNumber: 'BTR2025001',
              paymentDate: '2025-01-04',
              recordedBy: 'Finance Officer'
            }
          ]
          resolve(history)
        }, 500)
      })
    } catch (error) {
      console.error('Failed to get payment history:', error)
      throw error
    } finally {
      loading.value = false
    }
  }
  
  return {
    invoices,
    loading,
    collectedThisMonth,
    outstanding,
    pendingPayments,
    collectionRate,
    loadInvoices,
    loadPaymentStats,
    recordPayment,
    getPaymentHistory
  }
}