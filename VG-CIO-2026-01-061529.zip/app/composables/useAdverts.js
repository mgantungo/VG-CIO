import { ref } from 'vue'

export const useAdverts = () => {
  const adverts = ref([])
  const loading = ref(false)
  
  const loadAdverts = async () => {
    loading.value = true
    try {
      // Mock data - replace with API call
      adverts.value = [
        {
          id: '1',
          reference: '#ADV-2025-001',
          clientName: 'MTN Uganda',
          advertTitle: 'New Year Campaign',
          platform: 'New Vision - Front Page',
          platformCategory: 'print',
          totalAmount: 15500000,
          status: 'pending',
          createdAt: '2025-01-04',
          attachments: 3
        },
        {
          id: '2',
          reference: '#ADV-2025-002',
          clientName: 'Coca-Cola',
          advertTitle: 'Prime Time TV Spot',
          platform: 'UBC TV - 30 sec',
          platformCategory: 'tv',
          totalAmount: 2500000,
          status: 'approved',
          createdAt: '2025-01-03',
          attachments: 5
        },
        {
          id: '3',
          reference: '#ADV-2025-003',
          clientName: 'Stanbic Bank',
          advertTitle: 'Radio Campaign',
          platform: 'Central Broadcasting',
          platformCategory: 'radio',
          totalAmount: 1800000,
          status: 'draft',
          createdAt: '2025-01-02',
          attachments: 2
        }
      ]
    } catch (error) {
      console.error('Failed to load adverts:', error)
      throw error
    } finally {
      loading.value = false
    }
  }
  
  const createAdvert = async (advertData) => {
    loading.value = true
    try {
      // Mock API call
      return new Promise((resolve) => {
        setTimeout(() => {
          const newAdvert = {
            id: Date.now().toString(),
            reference: `#ADV-2025-${Math.floor(Math.random() * 1000)}`,
            ...advertData,
            status: 'pending',
            createdAt: new Date().toISOString().split('T')[0]
          }
          adverts.value.unshift(newAdvert)
          resolve(newAdvert)
        }, 1000)
      })
    } catch (error) {
      console.error('Failed to create advert:', error)
      throw error
    } finally {
      loading.value = false
    }
  }
  
  const calculatePrice = async (data) => {
    // Mock calculation
    return new Promise((resolve) => {
      setTimeout(() => {
        const basePrice = 9470000
        const subtotal = basePrice * data.frequency
        const surcharge = subtotal * 0.1 // 10% surcharge
        const total = subtotal + surcharge
        
        resolve({
          basePrice,
          frequency: data.frequency,
          subtotal,
          surcharge,
          surchargePercentage: 10,
          total,
          currency: 'UGX'
        })
      }, 500)
    })
  }
  
  const deleteAdvert = async (advertId) => {
    loading.value = true
    try {
      // Mock API call
      return new Promise((resolve) => {
        setTimeout(() => {
          adverts.value = adverts.value.filter(a => a.id !== advertId)
          resolve()
        }, 500)
      })
    } catch (error) {
      console.error('Failed to delete advert:', error)
      throw error
    } finally {
      loading.value = false
    }
  }
  
  return {
    adverts,
    loading,
    loadAdverts,
    createAdvert,
    calculatePrice,
    deleteAdvert
  }
}