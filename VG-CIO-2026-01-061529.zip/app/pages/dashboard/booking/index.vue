<template>
  <div class="my-adverts-page">
    <div class="page-header">
      <h1>My Adverts</h1>
      <p>Track and manage all your advertising bookings</p>
    </div>

    <div class="content-card">
      <div class="search-filter-bar">
        <input 
          v-model="searchQuery"
          type="text" 
          class="search-input" 
          placeholder="Search adverts by client, title, or reference..."
        >
        <select v-model="platformFilter" class="filter-select">
          <option value="">All Platforms</option>
          <option value="print">Print Media</option>
          <option value="tv">Television</option>
          <option value="radio">Radio</option>
          <option value="digital">Digital</option>
        </select>
        <select v-model="statusFilter" class="filter-select">
          <option value="">All Status</option>
          <option value="draft">Draft</option>
          <option value="pending">Pending Review</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
        <button class="btn btn-primary" @click="searchAdverts">Search</button>
        <button class="btn btn-secondary" @click="clearFilters">Clear</button>
      </div>

      <DataTable 
        :headers="tableHeaders"
        :items="filteredAdverts"
        :loading="loading"
      >
        <template #cell(actions)="{ item }">
          <div class="action-buttons">
            <button class="btn btn-info btn-sm" @click="viewAdvert(item)">
              View
            </button>
            <button 
              v-if="item.status === 'draft'"
              class="btn btn-warning btn-sm"
              @click="editAdvert(item)"
            >
              Edit
            </button>
            <button 
              v-if="item.status === 'approved'"
              class="btn btn-success btn-sm"
              @click="downloadAdvert(item)"
            >
              Download
            </button>
            <button 
              v-if="item.status === 'draft'"
              class="btn btn-danger btn-sm"
              @click="deleteAdvert(item)"
            >
              Delete
            </button>
          </div>
        </template>
      </DataTable>
    </div>
  </div>
</template>

<script setup>
import DataTable from '~/components/common/DataTable.vue'
import { useAdverts } from '~/composables/useAdverts'
import { ref, computed, onMounted } from 'vue'

const { 
  adverts, 
  loading, 
  loadAdverts: loadAdvertsApi,
  deleteAdvert: deleteAdvertApi 
} = useAdverts()

const searchQuery = ref('')
const platformFilter = ref('')
const statusFilter = ref('')

const tableHeaders = [
  { key: 'reference', label: 'Ref #' },
  { key: 'clientName', label: 'Client' },
  { key: 'advertTitle', label: 'Advert Title' },
  { key: 'platform', label: 'Platform' },
  { key: 'totalAmount', label: 'Amount (UGX)' },
  { key: 'status', label: 'Status' },
  { key: 'createdAt', label: 'Date' },
  { key: 'actions', label: 'Actions' }
]

const filteredAdverts = computed(() => {
  let filtered = [...adverts.value]
  
  if (searchQuery.value) {
    const query = searchQuery.value.toLowerCase()
    filtered = filtered.filter(advert => 
      advert.clientName?.toLowerCase().includes(query) ||
      advert.advertTitle?.toLowerCase().includes(query) ||
      advert.reference?.toLowerCase().includes(query)
    )
  }
  
  if (platformFilter.value) {
    filtered = filtered.filter(advert => 
      advert.platformCategory === platformFilter.value
    )
  }
  
  if (statusFilter.value) {
    filtered = filtered.filter(advert => 
      advert.status === statusFilter.value
    )
  }
  
  return filtered
})

onMounted(() => {
  loadAdvertsApi()
})

const searchAdverts = () => {
  // Search is handled by computed property
}

const clearFilters = () => {
  searchQuery.value = ''
  platformFilter.value = ''
  statusFilter.value = ''
}

const viewAdvert = (advert) => {
  navigateTo(`/adverts/${advert.id}`)
}

const editAdvert = (advert) => {
  navigateTo(`/dashboard/booking/new?id=${advert.id}`)
}

const downloadAdvert = async (advert) => {
  alert(`Downloading files for ${advert.reference}`)
  // Implementation for file download
}

const deleteAdvert = async (advert) => {
  if (confirm(`Are you sure you want to delete advert ${advert.reference}?`)) {
    try {
      await deleteAdvertApi(advert.id)
      alert('Advert deleted successfully')
    } catch (error) {
      console.error('Delete failed:', error)
      alert('Failed to delete advert')
    }
  }
}

const navigateTo = useRouter().push
</script>

<style scoped>
.my-adverts-page {
  width: 100%;
}

.page-header {
  background: white;
  padding: 20px 30px;
  border-radius: 10px;
  margin-bottom: 30px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.page-header h1 {
  color: #003366;
  margin-bottom: 10px;
}

.page-header p {
  color: #666;
}

.content-card {
  background: white;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.search-filter-bar {
  display: flex;
  gap: 15px;
  margin-bottom: 20px;
  flex-wrap: wrap;
  align-items: center;
}

.search-input {
  flex: 1;
  min-width: 250px;
  padding: 10px 15px;
  border: 1px solid #DDDDDD;
  border-radius: 5px;
}

.filter-select {
  padding: 10px 15px;
  border: 1px solid #DDDDDD;
  border-radius: 5px;
  min-width: 150px;
}

.btn {
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 1em;
  transition: all 0.3s;
}

.btn-primary {
  background: #E31E24;
  color: white;
}

.btn-primary:hover {
  background: #c01820;
}

.btn-secondary {
  background: #0066CC;
  color: white;
}

.btn-secondary:hover {
  background: #0052a3;
}

.btn-sm {
  padding: 6px 12px;
  font-size: 0.9em;
}

.btn-info {
  background: #17a2b8;
  color: white;
}

.btn-warning {
  background: #ffc107;
  color: #333333;
}

.btn-success {
  background: #28a745;
  color: white;
}

.btn-danger {
  background: #dc3545;
  color: white;
}

.action-buttons {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

@media (max-width: 768px) {
  .search-filter-bar {
    flex-direction: column;
    align-items: stretch;
  }
  
  .search-input,
  .filter-select {
    width: 100%;
  }
}
</style>