<template>
  <div class="booking-page">
    <div class="page-header">
      <h1>Book New Advert</h1>
      <p>Create a new advertising booking across Vision Group platforms</p>
    </div>

    <div class="content-card">
      <div class="card-header">
        <h2>Client & Advert Information</h2>
      </div>

      <form @submit.prevent="submitAdvert">
        <div class="form-row">
          <div class="form-group">
            <label>Client Name *</label>
            <input 
              v-model="form.clientName"
              type="text" 
              placeholder="e.g., MTN Uganda" 
              required
            >
          </div>
          <div class="form-group">
            <label>Contact Person</label>
            <input 
              v-model="form.contactPerson"
              type="text" 
              placeholder="Contact name"
            >
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>Email Address *</label>
            <input 
              v-model="form.email"
              type="email" 
              placeholder="client@company.com" 
              required
            >
          </div>
          <div class="form-group">
            <label>Phone Number *</label>
            <input 
              v-model="form.phone"
              type="tel" 
              placeholder="+256 700 000 000" 
              required
            >
          </div>
        </div>

        <div class="form-group">
          <label>Advert Title *</label>
          <input 
            v-model="form.advertTitle"
            type="text" 
            placeholder="e.g., MTN New Year Campaign" 
            required
          >
        </div>

        <div class="form-group">
          <label>Platform Category *</label>
          <select v-model="form.platformCategory" required @change="loadPlatforms">
            <option value="">Select platform category</option>
            <option value="print">Print Media</option>
            <option value="tv">Television</option>
            <option value="radio">Radio</option>
            <option value="digital">Digital Media</option>
            <option value="outdoor">Outdoor/OOH</option>
          </select>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>Specific Platform *</label>
            <select v-model="form.specificPlatform" required @change="loadProducts">
              <option value="">Select category first</option>
              <option v-for="platform in platforms" :key="platform" :value="platform">
                {{ platform }}
              </option>
            </select>
          </div>
          <div class="form-group">
            <label>Product/Section *</label>
            <select v-model="form.product" required @change="loadRateCards">
              <option value="">Select platform first</option>
              <option v-for="product in products" :key="product.id" :value="product.id">
                {{ product.name }}
              </option>
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>Rate Card *</label>
            <select v-model="form.rateCardId" required @change="calculatePrice">
              <option value="">Select product first</option>
              <option v-for="card in rateCards" :key="card.id" :value="card.id">
                {{ card.name }} - {{ formatCurrency(card.basePrice) }}
              </option>
            </select>
          </div>
          <div class="form-group">
            <label>Color/Type</label>
            <select v-model="form.adType" @change="calculatePrice">
              <option value="full_color">Full Color</option>
              <option value="black_white">Black & White</option>
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>Start Date *</label>
            <input 
              v-model="form.startDate"
              type="date" 
              required
            >
          </div>
          <div class="form-group">
            <label>End Date</label>
            <input 
              v-model="form.endDate"
              type="date"
            >
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>Frequency</label>
            <input 
              v-model="form.frequency"
              type="number" 
              placeholder="Number of insertions" 
              min="1" 
              @change="calculatePrice"
            >
          </div>
          <div class="form-group">
            <label>Payment Method *</label>
            <select v-model="form.paymentMethod" required>
              <option value="">Select payment method</option>
              <option value="cash">Cash</option>
              <option value="credit">Credit (Requires Approval)</option>
              <option value="cheque">Post-Dated Cheque</option>
              <option value="bank_transfer">Bank Transfer</option>
              <option value="mobile_money">Mobile Money</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label>Special Instructions</label>
          <textarea 
            v-model="form.specialInstructions"
            rows="4" 
            placeholder="Any special requirements or instructions..."
          ></textarea>
        </div>

        <PriceCalculator 
          :calculation="priceCalculation"
          :loading="priceLoading"
        />

        <FileUpload 
          @files-updated="handleFilesUpdate"
        />

        <div class="form-actions">
          <button type="button" class="btn btn-secondary" @click="saveDraft">
            Save as Draft
          </button>
          <button type="submit" class="btn btn-primary" :disabled="submitting">
            {{ submitting ? 'Submitting...' : 'Submit for Review' }}
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup>
import PriceCalculator from '~/components/clerk/PriceCalculator.vue'
import FileUpload from '~/components/clerk/FileUpload.vue'
import { useProducts } from '~/composables/useProducts'
import { useAdverts } from '~/composables/useAdverts'
import { ref, reactive, computed } from 'vue'

const { 
  platforms,
  products,
  rateCards,
  loadPlatforms: loadPlatformsApi,
  loadProducts: loadProductsApi,
  loadRateCards: loadRateCardsApi
} = useProducts()

const { createAdvert, calculatePrice: calculatePriceApi } = useAdverts()

const form = reactive({
  clientName: '',
  contactPerson: '',
  email: '',
  phone: '',
  advertTitle: '',
  platformCategory: '',
  specificPlatform: '',
  product: '',
  rateCardId: '',
  adType: 'full_color',
  startDate: '',
  endDate: '',
  frequency: 1,
  paymentMethod: '',
  specialInstructions: '',
  files: []
})

const priceCalculation = ref(null)
const priceLoading = ref(false)
const submitting = ref(false)

const loadPlatforms = async () => {
  await loadPlatformsApi(form.platformCategory)
  form.specificPlatform = ''
  form.product = ''
  form.rateCardId = ''
}

const loadProducts = async () => {
  await loadProductsApi(form.specificPlatform)
  form.product = ''
  form.rateCardId = ''
}

const loadRateCards = async () => {
  await loadRateCardsApi(form.product)
  form.rateCardId = ''
  calculatePrice()
}

const calculatePrice = async () => {
  if (!form.rateCardId || !form.frequency || !form.adType) return
  
  try {
    priceLoading.value = true
    const data = await calculatePriceApi({
      productId: form.product,
      rateCardId: form.rateCardId,
      frequency: parseInt(form.frequency),
      adType: form.adType
    })
    priceCalculation.value = data
  } catch (error) {
    console.error('Price calculation failed:', error)
  } finally {
    priceLoading.value = false
  }
}

const handleFilesUpdate = (files) => {
  form.files = files
}

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('en-UG', {
    style: 'currency',
    currency: 'UGX'
  }).format(amount)
}

const saveDraft = () => {
  alert('Draft saved successfully!')
  // In real implementation, would call API
}

const submitAdvert = async () => {
  try {
    submitting.value = true
    const result = await createAdvert({
      ...form,
      totalAmount: priceCalculation.value?.total || 0
    })
    
    alert(`Advert submitted successfully! Reference: ${result.referenceNumber}`)
    // Reset form
    Object.keys(form).forEach(key => {
      if (Array.isArray(form[key])) {
        form[key] = []
      } else {
        form[key] = ''
      }
    })
    form.frequency = 1
    form.adType = 'full_color'
    priceCalculation.value = null
  } catch (error) {
    console.error('Submission failed:', error)
    alert('Failed to submit advert. Please try again.')
  } finally {
    submitting.value = false
  }
}
</script>

<style scoped>
.booking-page {
  width: 100%;
}

.page-header {
  background: white;
  padding: 20px 30px;
  border-radius: 10px;
  margin-bottom: 30px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.page-header h1 {
  color: #003366;
  margin-bottom: 10px;
}

.page-header p {
  color: #666;
}

.content-card {
  background: white;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 25px;
  padding-bottom: 15px;
  border-bottom: 2px solid #F5F5F5;
}

.card-header h2 {
  color: #003366;
}

.form-row {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: #333333;
  font-weight: 500;
}

.form-group input,
.form-group select,
.form-group textarea {
  width: 100%;
  padding: 12px 15px;
  border: 1px solid #DDDDDD;
  border-radius: 5px;
  font-size: 1em;
  transition: border-color 0.3s;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  outline: none;
  border-color: #0066CC;
}

.form-actions {
  display: flex;
  gap: 15px;
  justify-content: flex-end;
  margin-top: 30px;
}

.btn {
  padding: 12px 24px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 1em;
  transition: all 0.3s;
}

.btn-primary {
  background: #E31E24;
  color: white;
}

.btn-primary:hover:not(:disabled) {
  background: #c01820;
}

.btn-primary:disabled {
  opacity: 0.7;
  cursor: not-allowed;
}

.btn-secondary {
  background: #0066CC;
  color: white;
}

.btn-secondary:hover {
  background: #0052a3;
}
</style>