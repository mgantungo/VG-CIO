<template>
  <div class="payments-page">
    <div class="page-header">
      <h1>Payment Collection</h1>
      <p>Manage payments and billing for advertising bookings</p>
    </div>

    <div class="stats-grid">
      <StatCard 
        icon="💰"
        :value="formatCurrency(collectedThisMonth)"
        label="Collected This Month"
        color="green"
      />
      <StatCard 
        icon="⏳"
        :value="formatCurrency(outstanding)"
        label="Outstanding"
        color="red"
      />
      <StatCard 
        icon="📊"
        :value="pendingPayments"
        label="Pending Payments"
        color="gold"
      />
      <StatCard 
        icon="✓"
        :value="`${collectionRate}%`"
        label="Collection Rate"
        color="blue"
      />
    </div>

    <div class="content-card">
      <div class="card-header">
        <h2>Payment Queue</h2>
      </div>

      <div class="tabs">
        <button 
          v-for="tab in tabs"
          :key="tab.id"
          class="tab"
          :class="{ active: activeTab === tab.id }"
          @click="activeTab = tab.id"
        >
          {{ tab.label }}
        </button>
      </div>

      <div class="tab-content active">
        <div class="search-filter-bar">
          <input 
            v-model="searchQuery"
            type="text" 
            class="search-input" 
            placeholder="Search by client, reference, or invoice..."
          >
          <select v-model="paymentMethodFilter" class="filter-select">
            <option value="">All Payment Methods</option>
            <option value="cash">Cash</option>
            <option value="credit">Credit</option>
            <option value="bank_transfer">Bank Transfer</option>
            <option value="mobile_money">Mobile Money</option>
          </select>
          <button class="btn btn-primary" @click="searchPayments">
            Search
          </button>
        </div>

        <DataTable 
          :headers="tableHeaders"
          :items="filteredInvoices"
          :loading="loading"
        >
          <template #cell(balance)="{ item }">
            <span :style="{ 
              color: item.balance === 0 ? '#28a745' : item.balance === item.totalAmount ? '#dc3545' : '#ffc107',
              fontWeight: 'bold'
            }">
              {{ formatCurrency(item.balance) }}
            </span>
          </template>
          
          <template #cell(status)="{ item }">
            <span :class="`status-badge status-${item.paymentStatus}`">
              {{ formatPaymentStatus(item.paymentStatus) }}
            </span>
          </template>
          
          <template #cell(actions)="{ item }">
            <div class="action-buttons">
              <button 
                v-if="item.balance > 0"
                class="btn btn-success btn-sm"
                @click="recordPayment(item)"
              >
                Record Payment
              </button>
              <button 
                v-if="item.paymentStatus === 'paid'"
                class="btn btn-info btn-sm"
                @click="viewReceipt(item)"
              >
                View Receipt
              </button>
              <button 
                class="btn btn-secondary btn-sm"
                @click="viewInvoice(item)"
              >
                Details
              </button>
            </div>
          </template>
        </DataTable>
      </div>
    </div>

    <PaymentModal 
      v-if="showPaymentModal"
      :invoice="selectedInvoice"
      @close="closePaymentModal"
      @payment-recorded="handlePaymentRecorded"
    />
  </div>
</template>

<script setup>
import StatCard from '~/components/common/StatCard.vue'
import DataTable from '~/components/common/DataTable.vue'
import PaymentModal from '~/components/finance/PaymentModal.vue'
import { usePayments } from '~/composables/usePayments'
import { ref, computed, onMounted } from 'vue'

const { 
  invoices,
  collectedThisMonth,
  outstanding,
  pendingPayments,
  collectionRate,
  loading,
  loadInvoices,
  loadPaymentStats 
} = usePayments()

const tabs = [
  { id: 'all', label: 'All' },
  { id: 'unpaid', label: 'Unpaid' },
  { id: 'partial', label: 'Partial' },
  { id: 'paid', label: 'Paid' },
  { id: 'overdue', label: 'Overdue' }
]

const activeTab = ref('all')
const searchQuery = ref('')
const paymentMethodFilter = ref('')
const selectedInvoice = ref(null)
const showPaymentModal = ref(false)

const tableHeaders = [
  { key: 'invoiceNumber', label: 'Invoice #' },
  { key: 'clientName', label: 'Client' },
  { key: 'advertReference', label: 'Advert Ref' },
  { key: 'totalAmount', label: 'Amount (UGX)' },
  { key: 'amountPaid', label: 'Paid (UGX)' },
  { key: 'balance', label: 'Balance (UGX)' },
  { key: 'paymentMethod', label: 'Payment Method' },
  { key: 'paymentStatus', label: 'Status' },
  { key: 'actions', label: 'Actions' }
]

const filteredInvoices = computed(() => {
  let filtered = [...invoices.value]
  
  // Filter by tab
  if (activeTab.value !== 'all') {
    filtered = filtered.filter(invoice => 
      invoice.paymentStatus === activeTab.value
    )
  }
  
  // Filter by search query
  if (searchQuery.value) {
    const query = searchQuery.value.toLowerCase()
    filtered = filtered.filter(invoice => 
      invoice.clientName?.toLowerCase().includes(query) ||
      invoice.advertReference?.toLowerCase().includes(query) ||
      invoice.invoiceNumber?.toLowerCase().includes(query)
    )
  }
  
  // Filter by payment method
  if (paymentMethodFilter.value) {
    filtered = filtered.filter(invoice => 
      invoice.paymentMethod === paymentMethodFilter.value
    )
  }
  
  return filtered
})

onMounted(() => {
  loadInvoices()
  loadPaymentStats()
})

const searchPayments = () => {
  // Search is handled by computed property
}

const formatCurrency = (amount) => {
  if (!amount) return 'UGX 0'
  return new Intl.NumberFormat('en-UG', {
    style: 'currency',
    currency: 'UGX'
  }).format(amount)
}

const formatPaymentStatus = (status) => {
  const statusMap = {
    'unpaid': 'Unpaid',
    'partial': 'Partial',
    'paid': 'Paid',
    'overdue': 'Overdue'
  }
  return statusMap[status] || status
}

const recordPayment = (invoice) => {
  selectedInvoice.value = invoice
  showPaymentModal.value = true
}

const closePaymentModal = () => {
  showPaymentModal.value = false
  selectedInvoice.value = null
}

const handlePaymentRecorded = () => {
  closePaymentModal()
  loadInvoices()
  loadPaymentStats()
}

const viewReceipt = (invoice) => {
  alert(`Viewing receipt for ${invoice.invoiceNumber}`)
}

const viewInvoice = (invoice) => {
  navigateTo(`/invoices/${invoice.id}`)
}

const navigateTo = useRouter().push
</script>

<style scoped>
.payments-page {
  width: 100%;
}

.page-header {
  background: white;
  padding: 20px 30px;
  border-radius: 10px;
  margin-bottom: 30px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.page-header h1 {
  color: #003366;
  margin-bottom: 10px;
}

.page-header p {
  color: #666;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
}

.content-card {
  background: white;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 25px;
  padding-bottom: 15px;
  border-bottom: 2px solid #F5F5F5;
}

.card-header h2 {
  color: #003366;
}

.tabs {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
  border-bottom: 2px solid #DDDDDD;
}

.tab {
  padding: 12px 24px;
  cursor: pointer;
  border: none;
  background: none;
  color: #666;
  font-size: 1em;
  border-bottom: 3px solid transparent;
  transition: all 0.3s;
}

.tab:hover {
  color: #E31E24;
}

.tab.active {
  color: #E31E24;
  border-bottom-color: #E31E24;
}

.search-filter-bar {
  display: flex;
  gap: 15px;
  margin-bottom: 20px;
  flex-wrap: wrap;
  align-items: center;
}

.search-input {
  flex: 1;
  min-width: 250px;
  padding: 10px 15px;
  border: 1px solid #DDDDDD;
  border-radius: 5px;
}

.filter-select {
  padding: 10px 15px;
  border: 1px solid #DDDDDD;
  border-radius: 5px;
  min-width: 150px;
}

.btn {
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 1em;
  transition: all 0.3s;
}

.btn-primary {
  background: #E31E24;
  color: white;
}

.btn-primary:hover {
  background: #c01820;
}

.btn-secondary {
  background: #0066CC;
  color: white;
}

.btn-secondary:hover {
  background: #0052a3;
}

.btn-sm {
  padding: 6px 12px;
  font-size: 0.9em;
}

.btn-success {
  background: #28a745;
  color: white;
}

.btn-info {
  background: #17a2b8;
  color: white;
}

.action-buttons {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.status-badge {
  padding: 5px 12px;
  border-radius: 20px;
  font-size: 0.85em;
  font-weight: 600;
}

.status-unpaid {
  background: #fab1a0;
  color: #e17055;
}

.status-partial {
  background: #ffeaa7;
  color: #636e72;
}

.status-paid {
  background: #55efc4;
  color: #00b894;
}

.status-overdue {
  background: #ff7675;
  color: #d63031;
}

@media (max-width: 768px) {
  .search-filter-bar {
    flex-direction: column;
    align-items: stretch;
  }
  
  .search-input,
  .filter-select {
    width: 100%;
  }
  
  .tabs {
    flex-wrap: wrap;
  }
}
</style>