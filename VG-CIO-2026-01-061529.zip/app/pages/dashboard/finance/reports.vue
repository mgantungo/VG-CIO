<template>
  <div class="reports-page">
    <div class="page-header">
      <h1>Billing Reports</h1>
      <p>Generate and manage billing reports and invoices</p>
    </div>

    <div class="content-card">
      <div class="card-header">
        <h2>Generate Report</h2>
      </div>

      <form @submit.prevent="generateReport">
        <div class="form-row">
          <div class="form-group">
            <label>Report Type</label>
            <select v-model="form.reportType" required>
              <option value="">Select report type</option>
              <option value="revenue_summary">Revenue Summary</option>
              <option value="payment_collection">Payment Collection</option>
              <option value="outstanding_invoices">Outstanding Invoices</option>
              <option value="platform_performance">Platform Performance</option>
              <option value="client_activity">Client Activity</option>
              <option value="tax_report">Tax Report</option>
            </select>
          </div>
          <div class="form-group">
            <label>Period</label>
            <select v-model="form.period" required>
              <option value="">Select period</option>
              <option value="this_month">This Month</option>
              <option value="last_month">Last Month</option>
              <option value="this_quarter">This Quarter</option>
              <option value="last_quarter">Last Quarter</option>
              <option value="this_year">This Year</option>
              <option value="custom">Custom Range</option>
            </select>
          </div>
        </div>

        <div v-if="form.period === 'custom'" class="form-row">
          <div class="form-group">
            <label>Start Date</label>
            <input v-model="form.startDate" type="date" required>
          </div>
          <div class="form-group">
            <label>End Date</label>
            <input v-model="form.endDate" type="date" required>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>Platform Filter</label>
            <select v-model="form.platformFilter">
              <option value="">All Platforms</option>
              <option value="print">Print Media</option>
              <option value="tv">Television</option>
              <option value="radio">Radio</option>
              <option value="digital">Digital Media</option>
            </select>
          </div>
          <div class="form-group">
            <label>Export Format</label>
            <select v-model="form.exportFormat" required>
              <option value="pdf">PDF</option>
              <option value="excel">Excel (XLSX)</option>
              <option value="csv">CSV</option>
            </select>
          </div>
        </div>

        <div v-if="form.reportType === 'client_activity'" class="form-group">
          <label>Client Filter (Optional)</label>
          <select v-model="form.clientId">
            <option value="">All Clients</option>
            <option v-for="client in clients" :key="client.id" :value="client.id">
              {{ client.name }}
            </option>
          </select>
        </div>

        <div class="form-actions">
          <button type="submit" class="btn btn-primary" :disabled="generating">
            {{ generating ? 'Generating...' : 'Generate Report' }}
          </button>
          <button type="button" class="btn btn-secondary" @click="previewReport">
            Preview
          </button>
          <button type="button" class="btn btn-warning" @click="resetForm">
            Reset
          </button>
        </div>
      </form>
    </div>

    <div class="content-card">
      <div class="card-header">
        <h2>Recent Reports</h2>
        <div class="sort-controls">
          <label>Sort by:</label>
          <select v-model="sortBy" @change="sortReports">
            <option value="date">Date</option>
            <option value="name">Name</option>
            <option value="type">Type</option>
          </select>
        </div>
      </div>

      <DataTable 
        :headers="tableHeaders"
        :items="sortedReports"
        :loading="loading"
      >
        <template #cell(type)="{ value }">
          {{ formatReportType(value) }}
        </template>
        
        <template #cell(date)="{ value }">
          {{ formatDateTime(value) }}
        </template>
        
        <template #cell(actions)="{ item }">
          <div class="action-buttons">
            <button class="btn btn-info btn-sm" @click="downloadReport(item)">
              Download
            </button>
            <button class="btn btn-warning btn-sm" @click="regenerateReport(item)">
              Regenerate
            </button>
            <button class="btn btn-danger btn-sm" @click="deleteReport(item)">
              Delete
            </button>
          </div>
        </template>
      </DataTable>
    </div>

    <div v-if="reportPreview" class="content-card">
      <div class="card-header">
        <h2>Report Preview</h2>
        <button class="btn btn-secondary" @click="closePreview">
          Close Preview
        </button>
      </div>
      
      <div class="report-preview">
        <div v-if="reportPreview.type === 'revenue_summary'" class="revenue-summary">
          <h3>Revenue Summary Report</h3>
          <div class="preview-stats">
            <div class="stat">
              <label>Total Revenue</label>
              <div class="value">{{ formatCurrency(reportPreview.data.totalRevenue) }}</div>
            </div>
            <div class="stat">
              <label>Total Invoices</label>
              <div class="value">{{ reportPreview.data.totalInvoices }}</div>
            </div>
            <div class="stat">
              <label>Paid Invoices</label>
              <div class="value">{{ reportPreview.data.paidInvoices }}</div>
            </div>
          </div>
          
          <div class="platform-breakdown">
            <h4>Platform Breakdown</h4>
            <table class="preview-table">
              <thead>
                <tr>
                  <th>Platform</th>
                  <th>Revenue</th>
                  <th>% of Total</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="platform in reportPreview.data.platforms" :key="platform.name">
                  <td>{{ platform.name }}</td>
                  <td>{{ formatCurrency(platform.revenue) }}</td>
                  <td>{{ platform.percentage }}%</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        <!-- Add other report type previews -->
      </div>
    </div>
  </div>
</template>

<script setup>
import DataTable from '~/components/common/DataTable.vue'
import { ref, computed, onMounted } from 'vue'
import { formatCurrency, formatDateTime } from '~/utils/formatters'

const reports = ref([])
const clients = ref([])
const loading = ref(false)
const generating = ref(false)
const sortBy = ref('date')
const reportPreview = ref(null)

const form = ref({
  reportType: '',
  period: '',
  startDate: '',
  endDate: '',
  platformFilter: '',
  exportFormat: 'pdf',
  clientId: ''
})

const tableHeaders = [
  { key: 'name', label: 'Report Name' },
  { key: 'type', label: 'Type' },
  { key: 'period', label: 'Period' },
  { key: 'generatedBy', label: 'Generated By' },
  { key: 'date', label: 'Date' },
  { key: 'size', label: 'Size' },
  { key: 'actions', label: 'Actions' }
]

const sortedReports = computed(() => {
  return [...reports.value].sort((a, b) => {
    if (sortBy.value === 'date') {
      return new Date(b.date) - new Date(a.date)
    }
    if (sortBy.value === 'name') {
      return a.name.localeCompare(b.name)
    }
    return a.type.localeCompare(b.type)
  })
})

onMounted(() => {
  loadReports()
  loadClients()
})

const loadReports = async () => {
  loading.value = true
  try {
    // Mock data
    reports.value = [
      {
        id: '1',
        name: 'December Revenue Summary',
        type: 'revenue_summary',
        period: 'Dec 1-31, 2024',
        generatedBy: 'Finance Manager',
        date: '2025-01-02T10:30:00Z',
        size: '2.4 MB',
        format: 'pdf'
      },
      {
        id: '2',
        name: 'Q4 2024 Performance',
        type: 'platform_performance',
        period: 'Oct-Dec 2024',
        generatedBy: 'Finance Manager',
        date: '2025-01-03T14:45:00Z',
        size: '3.1 MB',
        format: 'excel'
      },
      {
        id: '3',
        name: 'January Outstanding Invoices',
        type: 'outstanding_invoices',
        period: 'Jan 1-31, 2025',
        generatedBy: 'Accountant',
        date: '2025-02-01T09:15:00Z',
        size: '1.8 MB',
        format: 'pdf'
      }
    ]
  } catch (error) {
    console.error('Failed to load reports:', error)
  } finally {
    loading.value = false
  }
}

const loadClients = async () => {
  try {
    // Mock data
    clients.value = [
      { id: '1', name: 'MTN Uganda' },
      { id: '2', name: 'Coca-Cola' },
      { id: '3', name: 'Airtel Uganda' },
      { id: '4', name: 'Stanbic Bank' },
      { id: '5', name: 'Bank of Africa' }
    ]
  } catch (error) {
    console.error('Failed to load clients:', error)
  }
}

const formatReportType = (type) => {
  const typeMap = {
    revenue_summary: 'Revenue Summary',
    payment_collection: 'Payment Collection',
    outstanding_invoices: 'Outstanding Invoices',
    platform_performance: 'Platform Performance',
    client_activity: 'Client Activity',
    tax_report: 'Tax Report'
  }
  return typeMap[type] || type
}

const generateReport = async () => {
  if (!validateForm()) return
  
  generating.value = true
  try {
    // Mock report generation
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    const reportName = `${form.value.reportType.replace('_', ' ')} - ${new Date().toLocaleDateString()}`
    
    const newReport = {
      id: Date.now().toString(),
      name: reportName,
      type: form.value.reportType,
      period: getPeriodLabel(),
      generatedBy: 'You',
      date: new Date().toISOString(),
      size: '1.5 MB',
      format: form.value.exportFormat
    }
    
    reports.value.unshift(newReport)
    alert(`Report "${reportName}" generated successfully!`)
    resetForm()
  } catch (error) {
    console.error('Failed to generate report:', error)
    alert('Failed to generate report')
  } finally {
    generating.value = false
  }
}

const validateForm = () => {
  if (!form.value.reportType) {
    alert('Please select a report type')
    return false
  }
  
  if (!form.value.period) {
    alert('Please select a period')
    return false
  }
  
  if (form.value.period === 'custom' && (!form.value.startDate || !form.value.endDate)) {
    alert('Please select start and end dates for custom range')
    return false
  }
  
  return true
}

const getPeriodLabel = () => {
  if (form.value.period === 'custom') {
    return `${form.value.startDate} to ${form.value.endDate}`
  }
  
  const periodMap = {
    this_month: 'This Month',
    last_month: 'Last Month',
    this_quarter: 'This Quarter',
    last_quarter: 'Last Quarter',
    this_year: 'This Year'
  }
  
  return periodMap[form.value.period] || form.value.period
}

const previewReport = () => {
  if (!validateForm()) return
  
  // Mock preview data
  reportPreview.value = {
    type: form.value.reportType,
    data: {
      totalRevenue: 45000000,
      totalInvoices: 45,
      paidInvoices: 32,
      platforms: [
        { name: 'New Vision', revenue: 18500000, percentage: 41 },
        { name: 'Bukedde', revenue: 12300000, percentage: 27 },
        { name: 'UBC TV', revenue: 8700000, percentage: 19 },
        { name: 'Radio Stations', revenue: 5500000, percentage: 13 }
      ]
    }
  }
}

const closePreview = () => {
  reportPreview.value = null
}

const resetForm = () => {
  form.value = {
    reportType: '',
    period: '',
    startDate: '',
    endDate: '',
    platformFilter: '',
    exportFormat: 'pdf',
    clientId: ''
  }
  reportPreview.value = null
}

const downloadReport = (report) => {
  alert(`Downloading report: ${report.name}`)
}

const regenerateReport = (report) => {
  if (confirm(`Regenerate report: ${report.name}?`)) {
    // Implement regeneration
    alert('Report regeneration started')
  }
}

const deleteReport = (report) => {
  if (confirm(`Delete report: ${report.name}?`)) {
    reports.value = reports.value.filter(r => r.id !== report.id)
    alert('Report deleted')
  }
}

const sortReports = () => {
  // Sorting is handled by computed property
}
</script>

<style scoped>
.reports-page {
  width: 100%;
}

.page-header {
  background: white;
  padding: 20px 30px;
  border-radius: 10px;
  margin-bottom: 30px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.page-header h1 {
  color: #003366;
  margin-bottom: 10px;
}

.page-header p {
  color: #666;
}

.content-card {
  background: white;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 25px;
  padding-bottom: 15px;
  border-bottom: 2px solid #F5F5F5;
}

.card-header h2 {
  color: #003366;
}

.sort-controls {
  display: flex;
  align-items: center;
  gap: 10px;
}

.sort-controls label {
  color: #666;
  font-size: 0.9em;
}

.sort-controls select {
  padding: 8px 12px;
  border: 1px solid #DDDDDD;
  border-radius: 5px;
}

.form-row {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: #333333;
  font-weight: 500;
}

.form-group input,
.form-group select {
  width: 100%;
  padding: 12px 15px;
  border: 1px solid #DDDDDD;
  border-radius: 5px;
  font-size: 1em;
  transition: border-color 0.3s;
}

.form-group input:focus,
.form-group select:focus {
  outline: none;
  border-color: #0066CC;
}

.form-actions {
  display: flex;
  gap: 15px;
  justify-content: flex-end;
  margin-top: 30px;
}

.btn {
  padding: 12px 24px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 1em;
  transition: all 0.3s;
}

.btn-primary {
  background: #E31E24;
  color: white;
}

.btn-primary:hover:not(:disabled) {
  background: #c01820;
}

.btn-primary:disabled {
  opacity: 0.7;
  cursor: not-allowed;
}

.btn-secondary {
  background: #0066CC;
  color: white;
}

.btn-secondary:hover {
  background: #0052a3;
}

.btn-warning {
  background: #ffc107;
  color: #333333;
}

.btn-warning:hover {
  background: #e0a800;
}

.btn-danger {
  background: #dc3545;
  color: white;
}

.btn-sm {
  padding: 6px 12px;
  font-size: 0.9em;
}

.btn-info {
  background: #17a2b8;
  color: white;
}

.action-buttons {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.report-preview {
  padding: 20px;
  background: #F5F5F5;
  border-radius: 5px;
  margin-top: 20px;
}

.revenue-summary h3 {
  color: #003366;
  margin-bottom: 20px;
}

.preview-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
}

.preview-stats .stat {
  background: white;
  padding: 20px;
  border-radius: 5px;
  text-align: center;
}

.preview-stats .stat label {
  display: block;
  color: #666;
  font-size: 0.9em;
  margin-bottom: 8px;
}

.preview-stats .stat .value {
  font-size: 1.5em;
  font-weight: bold;
  color: #003366;
}

.platform-breakdown {
  margin-top: 30px;
}

.platform-breakdown h4 {
  color: #003366;
  margin-bottom: 15px;
}

.preview-table {
  width: 100%;
  border-collapse: collapse;
  background: white;
  border-radius: 5px;
  overflow: hidden;
}

.preview-table thead {
  background: #003366;
  color: white;
}

.preview-table th,
.preview-table td {
  padding: 12px 15px;
  text-align: left;
  border-bottom: 1px solid #DDDDDD;
}

.preview-table tbody tr:hover {
  background: #F5F5F5;
}

@media (max-width: 768px) {
  .card-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 15px;
  }
  
  .sort-controls {
    width: 100%;
    justify-content: flex-end;
  }
  
  .form-actions {
    flex-direction: column;
  }
  
  .action-buttons {
    justify-content: center;
  }
}
</style>