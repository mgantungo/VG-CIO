<template>
  <div class="landing-page">
    <div class="hero-section">
      <div class="hero-logo">VG</div>
      <h1>Vision Group Advertising Management System</h1>
      <p>Streamline your advertising operations across Print, TV, Radio, Digital, and more. From booking to billing, manage everything in one powerful platform.</p>
      <button class="cta-button" @click="navigateTo('/login')">Get Started →</button>
    </div>

    <div class="features-section">
      <h2>What You Can Do</h2>
      <p>A comprehensive solution for managing advertising across all Vision Group platforms</p>

      <div class="features-grid">
        <div v-for="feature in features" :key="feature.title" class="feature-card">
          <div class="feature-icon">{{ feature.icon }}</div>
          <h3>{{ feature.title }}</h3>
          <p>{{ feature.description }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
const navigateTo = useRouter().push

// Specify layout for this page
definePageMeta({
  layout: 'auth' // Use the auth layout which doesn't have AppHeader/SideMenu
})

const features = ref([
  {
    icon: '📝',
    title: 'Advert Booking',
    description: 'Clerks can create and book adverts across multiple platforms (New Vision, Bukedde, TV, Radio, Digital). Upload supporting documents, images, videos, and PDFs. Real-time pricing calculation based on comprehensive rate cards.'
  },
  {
    icon: '✓',
    title: 'Editorial Review',
    description: 'Sub-editors review submitted adverts for compliance and quality. Approve or reject with comments. Assign adverts to specific platforms and time slots.'
  },
  {
    icon: '👨‍💼',
    title: 'Manager Approval',
    description: 'Advertising managers review revenue projections vs costs. Financial oversight and final approval. Download advert attachments for review.'
  },
  {
    icon: '🎨',
    title: 'Design House',
    description: 'Access approved adverts and download all attachments. Upload newly developed creative materials. Version control for design iterations.'
  },
  {
    icon: '💰',
    title: 'Finance & Billing',
    description: 'Track payments against bookings. Multiple payment methods (Cash, Credit, PDC). Revenue reporting and analytics. Payment collection workflow.'
  },
  {
    icon: '📊',
    title: 'Analytics Dashboard',
    description: 'Real-time revenue tracking across all platforms. Performance metrics by product category. Client activity and payment status monitoring.'
  },
  {
    icon: '🔐',
    title: 'Role-Based Access',
    description: 'Secure login for different user types. Clerks, Editors, Managers, Design Team, Finance. Customized dashboards per role.'
  },
  {
    icon: '📱',
    title: 'Multi-Platform Support',
    description: 'Manage adverts for Print (New Vision, Bukedde, supplements). Broadcast (UBC TV, Bukedde TV, Radio stations). Digital (Websites, Apps, Social Media).'
  },
  {
    icon: '📄',
    title: 'Document Management',
    description: 'Centralized storage for all advert materials. Support for Word documents, PDFs, images, videos. Easy retrieval and reference system.'
  }
])
</script>

<style scoped>
.landing-page {
  width: 100%;
}

.hero-section {
  background: linear-gradient(135deg, #003366 0%, #0066CC 100%);
  color: white;
  padding: 100px 20px;
  text-align: center;
}

.hero-section h1 {
  font-size: 3em;
  margin-bottom: 20px;
  font-weight: 700;
}

.hero-section p {
  font-size: 1.3em;
  margin-bottom: 30px;
  max-width: 800px;
  margin-left: auto;
  margin-right: auto;
}

.hero-logo {
  width: 150px;
  height: 150px;
  margin: 0 auto 30px;
  background: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2em;
  font-weight: bold;
  color: #E31E24;
}

.cta-button {
  background: #E31E24;
  color: white;
  padding: 15px 40px;
  border: none;
  border-radius: 5px;
  font-size: 1.1em;
  cursor: pointer;
  text-decoration: none;
  display: inline-block;
  transition: background 0.3s;
}

.cta-button:hover {
  background: #c01820;
}

.features-section {
  padding: 80px 20px;
  max-width: 1200px;
  margin: 0 auto;
  background: white;
}

.features-section h2 {
  text-align: center;
  color: #003366;
  font-size: 2.5em;
  margin-bottom: 20px;
}

.features-section > p {
  text-align: center;
  color: #666;
  max-width: 800px;
  margin: 0 auto 50px;
  font-size: 1.1em;
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 30px;
  margin-top: 50px;
}

.feature-card {
  background: white;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
  border-left: 4px solid #E31E24;
  transition: transform 0.3s;
}

.feature-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 6px 12px rgba(0,0,0,0.15);
}

.feature-icon {
  width: 60px;
  height: 60px;
  background: #0066CC;
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5em;
  margin-bottom: 20px;
}

.feature-card h3 {
  color: #003366;
  margin-bottom: 15px;
  font-size: 1.3em;
}

.feature-card p {
  color: #666;
  line-height: 1.8;
}
</style>