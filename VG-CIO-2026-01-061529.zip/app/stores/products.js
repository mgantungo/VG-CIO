import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useProductsStore = defineStore('products', () => {
  const categories = ref([
    { id: 'print', name: 'Print Media', icon: '📰' },
    { id: 'tv', name: 'Television', icon: '📺' },
    { id: 'radio', name: 'Radio', icon: '📻' },
    { id: 'digital', name: 'Digital Media', icon: '🌐' },
    { id: 'outdoor', name: 'Outdoor/OOH', icon: '🏙️' }
  ])
  
  const platforms = ref([
    // Print Media
    { id: 'new-vision', name: 'New Vision', category: 'print' },
    { id: 'bukedde', name: 'Bukedde', category: 'print' },
    { id: 'weekend-vision', name: 'Weekend Vision', category: 'print' },
    { id: 'bukedde-ku-wiikendi', name: 'Bukedde Ku Wiikendi', category: 'print' },
    
    // Television
    { id: 'ubc-tv', name: 'UBC TV', category: 'tv' },
    { id: 'bukedde-tv', name: 'Bukedde TV', category: 'tv' },
    
    // Radio
    { id: 'central-broadcasting', name: 'Central Broadcasting', category: 'radio' },
    { id: 'other-radios', name: 'Other Radio Stations', category: 'radio' },
    
    // Digital
    { id: 'website-new-vision', name: 'Website - New Vision', category: 'digital' },
    { id: 'website-bukedde', name: 'Website - Bukedde', category: 'digital' },
    { id: 'mobile-app', name: 'Mobile App', category: 'digital' },
    { id: 'social-media', name: 'Social Media', category: 'digital' },
    
    // Outdoor
    { id: 'billboards', name: 'Billboards', category: 'outdoor' },
    { id: 'transit-advertising', name: 'Transit Advertising', category: 'outdoor' },
    { id: 'experiential', name: 'Experiential Marketing', category: 'outdoor' }
  ])
  
  const products = ref([
    // New Vision Products
    { id: 'front-page', name: 'Front Page', platform: 'new-vision', category: 'display', basePrice: 9470000 },
    { id: 'back-page', name: 'Back Page', platform: 'new-vision', category: 'display', basePrice: 8500000 },
    { id: 'main-body', name: 'Main Body Display', platform: 'new-vision', category: 'display', basePrice: 6500000 },
    { id: 'classified', name: 'Classified Section', platform: 'new-vision', category: 'classified', basePrice: 500000 },
    
    // Bukedde Products
    { id: 'bukedde-front', name: 'Front Page', platform: 'bukedde', category: 'display', basePrice: 4500000 },
    { id: 'bukedde-main', name: 'Main Body', platform: 'bukedde', category: 'display', basePrice: 3500000 },
    
    // TV Products
    { id: 'prime-time-30s', name: 'Prime Time (30 sec)', platform: 'ubc-tv', category: 'spot', basePrice: 2500000 },
    { id: 'day-time-15s', name: 'Day Time (15 sec)', platform: 'ubc-tv', category: 'spot', basePrice: 1500000 },
    
    // Radio Products
    { id: 'radio-prime', name: 'Prime Time Package', platform: 'central-broadcasting', category: 'package', basePrice: 1800000 },
    
    // Digital Products
    { id: 'website-banner', name: 'Website Banner', platform: 'website-new-vision', category: 'display', basePrice: 1200000 },
    
    // Outdoor Products
    { id: 'billboard-premium', name: 'Premium Billboard', platform: 'billboards', category: 'display', basePrice: 8000000 }
  ])
  
  const rateCards = ref([
    // New Vision Front Page rates
    {
      id: 'rate-001',
      productId: 'front-page',
      name: 'Standard Rate',
      basePrice: 9470000,
      colorPrice: 9470000,
      bwPrice: 7500000,
      surchargePercentage: 10,
      effectiveDate: '2024-01-01',
      expiryDate: '2024-12-31',
      currency: 'UGX'
    },
    {
      id: 'rate-002',
      productId: 'front-page',
      name: 'Corporate Rate',
      basePrice: 8500000,
      colorPrice: 8500000,
      bwPrice: 6800000,
      surchargePercentage: 5,
      effectiveDate: '2024-01-01',
      expiryDate: '2024-12-31',
      currency: 'UGX'
    },
    
    // TV Rates
    {
      id: 'rate-003',
      productId: 'prime-time-30s',
      name: 'Prime Time Standard',
      basePrice: 2500000,
      colorPrice: 2500000,
      bwPrice: 2500000,
      surchargePercentage: 15,
      effectiveDate: '2024-01-01',
      expiryDate: '2024-12-31',
      currency: 'UGX'
    }
  ])
  
  const loading = ref(false)
  const error = ref(null)
  
  // Getters
  const getPlatformsByCategory = computed(() => {
    return (categoryId) => {
      return platforms.value.filter(platform => platform.category === categoryId)
    }
  })
  
  const getProductsByPlatform = computed(() => {
    return (platformId) => {
      return products.value.filter(product => product.platform === platformId)
    }
  })
  
  const getRateCardsByProduct = computed(() => {
    return (productId) => {
      return rateCards.value.filter(rateCard => rateCard.productId === productId)
    }
  })
  
  const getProductById = computed(() => {
    return (productId) => {
      return products.value.find(product => product.id === productId)
    }
  })
  
  // Actions
  const loadProducts = async () => {
    loading.value = true
    try {
      // In production, load from API
      // Mock data already initialized
    } catch (err) {
      error.value = err.message || 'Failed to load products'
      console.error('Error loading products:', err)
    } finally {
      loading.value = false
    }
  }
  
  const calculatePrice = async (productId, rateCardId, options = {}) => {
    try {
      const product = products.value.find(p => p.id === productId)
      const rateCard = rateCards.value.find(r => r.id === rateCardId)
      
      if (!product || !rateCard) {
        throw new Error('Product or rate card not found')
      }
      
      const basePrice = options.adType === 'bw' ? rateCard.bwPrice : rateCard.colorPrice
      const frequency = options.frequency || 1
      const subtotal = basePrice * frequency
      const surcharge = rateCard.surchargePercentage ? 
        subtotal * (rateCard.surchargePercentage / 100) : 0
      const total = subtotal + surcharge
      
      return {
        basePrice,
        frequency,
        subtotal,
        surcharge,
        surchargePercentage: rateCard.surchargePercentage || 0,
        total,
        currency: rateCard.currency,
        productName: product.name,
        rateCardName: rateCard.name
      }
    } catch (err) {
      error.value = err.message || 'Failed to calculate price'
      console.error('Error calculating price:', err)
      throw err
    }
  }
  
  const addRateCard = async (rateCardData) => {
    loading.value = true
    try {
      const newRateCard = {
        id: `rate-${Date.now()}`,
        ...rateCardData
      }
      rateCards.value.push(newRateCard)
      return newRateCard
    } catch (err) {
      error.value = err.message || 'Failed to add rate card'
      console.error('Error adding rate card:', err)
      throw err
    } finally {
      loading.value = false
    }
  }
  
  const updateRateCard = async (rateCardId, updates) => {
    loading.value = true
    try {
      const index = rateCards.value.findIndex(r => r.id === rateCardId)
      if (index !== -1) {
        rateCards.value[index] = { ...rateCards.value[index], ...updates }
      }
    } catch (err) {
      error.value = err.message || 'Failed to update rate card'
      console.error('Error updating rate card:', err)
      throw err
    } finally {
      loading.value = false
    }
  }
  
  return {
    // State
    categories,
    platforms,
    products,
    rateCards,
    loading,
    error,
    
    // Getters
    getPlatformsByCategory,
    getProductsByPlatform,
    getRateCardsByProduct,
    getProductById,
    
    // Actions
    loadProducts,
    calculatePrice,
    addRateCard,
    updateRateCard
  }
})