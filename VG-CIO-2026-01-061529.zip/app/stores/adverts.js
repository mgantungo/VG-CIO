import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useAdvertsStore = defineStore('adverts', () => {
  const adverts = ref([])
  const selectedAdvert = ref(null)
  const loading = ref(false)
  const error = ref(null)
  
  // Getters
  const draftAdverts = computed(() => {
    return adverts.value.filter(advert => advert.status === 'draft')
  })
  
  const pendingAdverts = computed(() => {
    return adverts.value.filter(advert => advert.status === 'pending_review')
  })
  
  const approvedAdverts = computed(() => {
    return adverts.value.filter(advert => 
      advert.status === 'editor_approved' || 
      advert.status === 'manager_approved'
    )
  })
  
  const totalRevenue = computed(() => {
    return adverts.value.reduce((sum, advert) => {
      if (advert.status !== 'rejected') {
        return sum + (advert.totalAmount || 0)
      }
      return sum
    }, 0)
  })
  
  // Actions
  const loadAdverts = async () => {
    loading.value = true
    error.value = null
    try {
      // In production, this would be an API call
      const mockAdverts = [
        {
          id: '1',
          reference: '#ADV-2025-001',
          clientName: 'MTN Uganda',
          advertTitle: 'New Year Campaign',
          platform: 'New Vision - Front Page',
          platformCategory: 'print',
          totalAmount: 15500000,
          status: 'pending_review',
          createdAt: '2025-01-04T09:30:00Z',
          createdBy: 'user1'
        },
        {
          id: '2',
          reference: '#ADV-2025-002',
          clientName: 'Coca-Cola',
          advertTitle: 'Prime Time TV Spot',
          platform: 'UBC TV - 30 sec',
          platformCategory: 'tv',
          totalAmount: 2500000,
          status: 'editor_approved',
          createdAt: '2025-01-03T14:20:00Z',
          createdBy: 'user2'
        },
        {
          id: '3',
          reference: '#ADV-2025-003',
          clientName: 'Stanbic Bank',
          advertTitle: 'Radio Campaign',
          platform: 'Central Broadcasting',
          platformCategory: 'radio',
          totalAmount: 1800000,
          status: 'draft',
          createdAt: '2025-01-02T11:15:00Z',
          createdBy: 'user1'
        }
      ]
      
      adverts.value = mockAdverts
    } catch (err) {
      error.value = err.message || 'Failed to load adverts'
      console.error('Error loading adverts:', err)
    } finally {
      loading.value = false
    }
  }
  
  const createAdvert = async (advertData) => {
    loading.value = true
    error.value = null
    try {
      // Mock API call
      const newAdvert = {
        id: Date.now().toString(),
        reference: `#ADV-2025-${Math.floor(Math.random() * 1000)}`,
        ...advertData,
        status: 'draft',
        createdAt: new Date().toISOString(),
        createdBy: 'current_user_id' // In production, get from auth store
      }
      
      adverts.value.unshift(newAdvert)
      return newAdvert
    } catch (err) {
      error.value = err.message || 'Failed to create advert'
      console.error('Error creating advert:', err)
      throw err
    } finally {
      loading.value = false
    }
  }
  
  const updateAdvert = async (advertId, updates) => {
    loading.value = true
    error.value = null
    try {
      const index = adverts.value.findIndex(a => a.id === advertId)
      if (index !== -1) {
        adverts.value[index] = { ...adverts.value[index], ...updates }
      }
    } catch (err) {
      error.value = err.message || 'Failed to update advert'
      console.error('Error updating advert:', err)
      throw err
    } finally {
      loading.value = false
    }
  }
  
  const deleteAdvert = async (advertId) => {
    loading.value = true
    error.value = null
    try {
      adverts.value = adverts.value.filter(a => a.id !== advertId)
    } catch (err) {
      error.value = err.message || 'Failed to delete advert'
      console.error('Error deleting advert:', err)
      throw err
    } finally {
      loading.value = false
    }
  }
  
  const setSelectedAdvert = (advertId) => {
    selectedAdvert.value = adverts.value.find(a => a.id === advertId) || null
  }
  
  const clearSelectedAdvert = () => {
    selectedAdvert.value = null
  }
  
  const submitForReview = async (advertId) => {
    return updateAdvert(advertId, { 
      status: 'pending_review',
      submittedAt: new Date().toISOString()
    })
  }
  
  const getAdvertById = (advertId) => {
    return adverts.value.find(a => a.id === advertId) || null
  }
  
  return {
    // State
    adverts,
    selectedAdvert,
    loading,
    error,
    
    // Getters
    draftAdverts,
    pendingAdverts,
    approvedAdverts,
    totalRevenue,
    
    // Actions
    loadAdverts,
    createAdvert,
    updateAdvert,
    deleteAdvert,
    setSelectedAdvert,
    clearSelectedAdvert,
    submitForReview,
    getAdvertById
  }
})